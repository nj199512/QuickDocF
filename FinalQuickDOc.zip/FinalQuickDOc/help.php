<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Sajha Hospital</title>
<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	<?php require_once '_navigation.php'; ?>
	<div id="body">
		<div class="general	">
			<h1>Help</h1>
			<div>
				<p>If you have any trouble in using this website, refer to this help file:<a href="user manual.pdf">help.pdf</a> or contact us through the contacts us page.

				</p>		
			</div>
		</div>
	</div>
		
</body>
</html>
