<!DOCTYPE html>
<html>
<head>
	<title>Doc Appoint |Articles</title>
</head>

<body style="font-family: 'Exo 2', sans-serif;background: url(https://vivifyhealth-xmqfat98oo.netdna-ssl.com/wp-content/uploads/2016/10/Background-24.png?x24614); background-size :cover;color:white; ">
	<?php include '_navigation.php';?>
	<div class="container">
		<img src="mentalhealth.jpg" width="30%" height="30%" border="4px solid black">
	<h2>Mental illness, Time to Talk About It!</h2>
	<h5>Dr. Anamay K. BidwaiGeneral Physician</h5>
	<h6>10 October, 2015</h6><br><br>

<p>Today is mental illness day.</p>

<p>Incidences of mental illness are going up in India, a recent study shows that every fourth Indian might be having some symptom or might have had some symptoms like depression, anxiety, panic attacks, phobias etc.</p>
<p>The reason for increase in the number of patients with mental illness is change in life style, increasing day to day stress, break down of joint family structure resulting in less moral support.</p>
<p>Another reason is increasing awareness about mental illness, more and more people are coming out to get treated, more and more are being diagnosed, so those who were hiding their disease and suffering in silence are now getting treatment and enjoying better quality of life.</p>
<p>Mental illness has been the taboo associated with it, time has come that we understand that brain too is an organ like any other organ like heart, liver or kidney.</p>
<p>So if heart, liver, kidney can develop malfunction why not brain? Like other organs brain too might have some problem, like heart, liver, kidney diseases, even brain can be treated with medicines and other measures.</p>
<p>There is nothing wrong if you have depression or anxiety, talk to your family members or close friends about it, see a psychiatrist, if you neglect your problem it will only increase with time.</p>
<p>There was a time when any one who went to a psychiatrist was considered " pagal" or " mad", it is not so any more, we must remove the taboo created around mental illness and accept it as any other health issue.</p>
<p>Many great people who had mental health issues like schizophrenia, dyslexia, autism, bipolar disorder, organic depression have gone on to win noble prizes, have made great inventions, gone to become heads of states, all this because they got treated in time, used their will power to come over the problem and made best use of their potential.</p>
<p>If you suffer from loss of sleep, unexplained loss of weight, loss of apatite, urge to remain alone all time, loss of interest in work, loss of interest in sex, mood swings, anxiety of going to crowded places, lethargy, unwillingness to meet new people, you must see a doctor and seek advice.</p>
<p>It is always very important to have a person with you during the steps of treatment, it may be your wife, mother, father, close friend or some one you trust. </p>
<p>Today, lets resolve  not to treat mental illness as taboo, lets open up and understand that a person with mental illness can be treated, with treatment he/she can enjoy a good quality of life and contribute positively to family and community.</p>
</div><br>
</p>

</body>
</html>