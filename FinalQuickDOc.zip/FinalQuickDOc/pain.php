<!DOCTYPE html>
<html>
<head>
	<title>Doc Appoint |Articles</title>
</head>

<body style="font-family: 'Exo 2', sans-serif;background: url(https://vivifyhealth-xmqfat98oo.netdna-ssl.com/wp-content/uploads/2016/10/Background-24.png?x24614); background-size :cover;color:white; ">
	<?php include '_navigation.php';?>
	<div class="container">
		<img src="pain.jpg" width="30%" height="30%" border="4px solid black">
	<h2>Knee Pain Treatment</h2>
	<h5>Dr.Prakash Jha(PT)Physiotherapist</h5>
	<h6>20 April, 2018</h6>

<p>
	
Causes of knee pains are multifactorial, since we have multiple structures in the knee and it's surrounding, hence the treatment of different types knee pain is different. Knee Osteoarthritis is a common cause of pain in older adults. Cartilage or Some people call it grease in their layman terminology develops until the age 35 years. Whatever amount of cartilage you have at 35 years, you have to maintain it throughout the rest of life to live pain-free around the knee. Maintenance is done by a range of motion exercise e.g. Cycling, Bending and straightening the knee etc.</p>

<p>A lot of people are worried about the gap between the two bones of leg in X-ray. A uniform gap is naturally present in X-ray between both the bones, the problem lies when the gap is minimized on one side, which means the cartilage of that side is eroded. Which brings a change in stability of Knee joint in movements for which the  exercises are- Pressing the towel with the knee (Isometric Exercise), Lifting the leg in sitting and holding it etc., But sometimes the problem lies outside the knee which troubles you at knee </p>

<p>
The compromised flexibility of thigh muscles and leg muscles
The weakness of hip muscles
The wrong pattern of movements 
Which subjects unnecessary load on knee lead to more wear and year leads to increased damage to the knee joint. In such cases treatment needs to be different.</p>

<p>When to use the hot pack and cold pack?</p>

<p>whenever there is swelling raised temperature around the pain-full area cold pack is recommended. 10 min twice daily is good.</p>

</p>Long-standing pain with stiffness is helped more with hot pack covering a good portion of thigh muscles as well. 15 min twice daily is good.<p>

<p>Knee PainEveryday Fitness</p>

</p>
</div><br>

</body>
</html>