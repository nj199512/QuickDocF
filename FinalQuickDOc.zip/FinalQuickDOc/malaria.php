<!DOCTYPE html>
<html>
<head>
	<title>Doc Appoint |Articles</title>
</head>

<body style="font-family: 'Exo 2', sans-serif;background: url(https://vivifyhealth-xmqfat98oo.netdna-ssl.com/wp-content/uploads/2016/10/Background-24.png?x24614); background-size :cover;color:white; ">
	<?php include '_navigation.php';?>
	<div class="container">
		<img src="malaria.jpg" width="30%" height="30%" border="4px solid black">
	<h2>Dengue</h2>
	<h5>Dr.Pravin Bhendarkar</h5>
	<h6>13 March, 2018</h6><br><br>

<p>
	About the disease:</p>

<p>Dengue also termed as the "Bone break fever".</p>
<p>It is caused by Flavivirus, it is spread by mosquito belonging to Aedes genus.</p>
<p>This is a febrile illness that can result in a fatal outcome in some cases.</p>
<p>Epidemiology and prevalence:</p>

<p>Dengue epidemic is seasonal in its appearance found mostly during the rains.</p>
<p>Dengue is a disease of the tropical and subtropical regions.</p>
<p>Mode of transmission and stages of dengue:</p>

<p>The causative agent is transmitted through an infected mosquito bite.</p>

<p>1. Febrile stage: This lasts for 5-7days and is characterized by high fever, headache and nausea.    </p>

<p>2. Critical stage: Some people progress to this stage after the fever resolves.It is characterized by increased fluid leakage into body cavities like peritoneum and pleura leading to dehydration and internal bleeding due to thrombocytopenia.</p>

<p>3. Recovery stage: It lasts for 48-72hrs. The extravasated fluid re-enters the intravascular compartments, and the platelet count starts increasing.</p>
<p>DengueFlu</p>
</p>
</div><br>

</body>
</html>