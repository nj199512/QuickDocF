<?php
$hostname ="localhost";
$username ="root";
$password ="";
$database ="quickdoc";

$conn = mysqli_connect($hostname,$username,$password,$database) or die("Database not connect");
?>