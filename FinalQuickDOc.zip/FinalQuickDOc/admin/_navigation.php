<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Sajha Hospital</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
</head>
<body>
	<div id="header">
			<div id="logo">
				<a href="index.html"><img src="../images/logo.jpg" alt="" /></a>		
			</div>		
			<ul>
				<li><a href="index.php"><span>home</span></a></li>
				<li><a href="removedoctors.php"><span>doctors</span></a></li>
				<li><a href="viewappointments.php"><span>appointment</span></a></li>
				<li><a href="feedbacks.php"><span>Feedbacks</span></a></li>
				<li><a href="../actions/backend_logout.php"><span>logout</span></a></li>						
			</ul>
	</div>
</body>
</html>